@extends('layouts.app')

@section('title', 'Cargar una Revisita')

@section('content')
En la próxima versión pongo las revisitas... <i class="fas fa-smile fa-2x"></i>
@endsection