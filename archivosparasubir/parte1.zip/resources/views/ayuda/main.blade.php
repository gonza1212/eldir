@extends('layouts.app')

@section('title', '¿Cómo usar?')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		Ayuda: Sección Principal
	</div>
	<div class="panel-body">
		Próximamente... <i class="fas fa-smile fa-2x"></i>
	</div>
</div>
@endsection