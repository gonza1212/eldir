<?php $__env->startSection('title', 'Registro de Versiones'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		Última Versión 0.2: Cambios introducidos
	</div>
	<div class="panel-body">
		<p>1 - Arreglado bug que mezclaba registros de actividad de un mes con otro.</p>
		<p>2 - Arreglada distribución de tablas en resoluciones bajas.</p>
		<p>3 - Agregados estilos CSS.</p>
		<p>4 - Arreglados bugs menores.</p>
	</div>
</div>
<div class="panel panel-default">
	<div class="panel-heading">
		Versiones anteriores
	</div>
	<div class="panel-body">
		<div class="table-responsive">
		<table class="table">
		  <thead>
		    <tr>
		      <th scope="col">Versión</th>
		      <th scope="col">Cambios</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <td>0.1</td>
		      <td>- Primera versión: alta del sistema.</td>
		    </tr>
		  </tbody>
		</table>		
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>