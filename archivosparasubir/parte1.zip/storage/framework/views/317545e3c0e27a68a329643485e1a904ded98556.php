<?php $__env->startSection('title', 'Mi Informe'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
	<div class="panel-heanding">
		<h3 class="text-center"><?php echo $meses[$hoy->month] . ' de ' . $hoy->year; ?></h3>
	</div>
	<div class="panel-body text-center">
		<h3><?php echo e($actividadActual[0]); ?><small> horas con </small><?php echo e($actividadActual[1]); ?><small> minutos, </small><?php echo e($actividadActual[2]); ?><small> publicaciones y </small><?php echo e($actividadActual[3]); ?><small> videos.</small></h3>
		<hr>
		<a class="btn btn-primary" id='collapseMesActual' data-toggle="collapse" href="#registrosActuales"><i class="fas fa-search"></i><?php echo e(' Ver registros de ' . $meses[$hoy->month] .' (' . count($actuales). ')'); ?></a>
        <div id="registrosActuales" class="panel-collapse collapse">
        	<div class="table-responsive">
		<table class="table">
	  <thead>
	    <tr>
	      <th scope="col">Fecha</th>
	      <th scope="col">Horas</th>
	      <th scope="col">Publicaciones</th>
	      <th scope="col">Videos</th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php $__currentLoopData = $actuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	      <td><?php echo Carbon\Carbon::parse($a->fecha)->toFormattedDateString(); ?></td>
	      <?php if($a->minutos > 9): ?>
	      <td><?php echo e($a->horas); ?>:<?php echo e($a->minutos); ?></td>
	      <?php else: ?>
	      <td><?php echo e($a->horas); ?>:0<?php echo e($a->minutos); ?></td>
	      <?php endif; ?>
	      <td><?php echo e($a->publicaciones); ?></td>
	      <td><?php echo e($a->videos); ?></td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  </tbody>
	</table>
</div>
</div>
	</div>
</div>
<div class="panel panel-default">
	<div class="panel-heanding">
		<h3 class="text-center"><?php echo $meses[($hoy->subMonth())->month] . ' de ' . $hoy->year; ?></h3>
	</div>
	<div class="panel-body text-center">
		<h3><?php echo e($actividadPasada[0]); ?><small> horas con </small><?php echo e($actividadPasada[1]); ?><small> minutos, </small><?php echo e($actividadPasada[2]); ?><small> publicaciones y </small><?php echo e($actividadPasada[3]); ?><small> videos.</small></h3>
		<hr>
		<a class="btn btn-primary" id='collapseMesPasado' data-toggle="collapse" href="#registrosPasados"><i class="fas fa-search"></i><?php echo e(' Ver registros de ' . $meses[$hoy->month] .' (' . count($pasadas). ')'); ?></a>
        <div id="registrosPasados" class="panel-collapse collapse">
        	<div class="table-responsive">
		<table class="table">
	  <thead>
	    <tr>
	      <th scope="col">Fecha</th>
	      <th scope="col">Horas</th>
	      <th scope="col">Publicaciones</th>
	      <th scope="col">Videos</th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php $__currentLoopData = $pasadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	      <td><?php echo Carbon\Carbon::parse($p->fecha)->toFormattedDateString(); ?></td>
	      <?php if($p->minutos > 9): ?>
	      <td><?php echo e($p->horas); ?>:<?php echo e($p->minutos); ?></td>
	      <?php else: ?>
	      <td><?php echo e($p->horas); ?>:0<?php echo e($p->minutos); ?></td>
	      <?php endif; ?>
	      <td><?php echo e($p->publicaciones); ?></td>
	      <td><?php echo e($p->videos); ?></td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  </tbody>
	</table>
</div>
</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>