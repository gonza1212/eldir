<?php $__env->startSection('title', 'Cargar una Revisita'); ?>

<?php $__env->startSection('content'); ?>
En la próxima versión pongo las revisitas... <i class="fas fa-smile fa-2x"></i>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>