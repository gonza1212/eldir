<?php $__env->startSection('title', 'Cargar Actividad'); ?>

<?php $__env->startSection('content'); ?>

<?php echo Form::open(['route' => 'actividad.store', 'files' => true]); ?>


	
	<div class="form-group">
		<?php echo Form::label('fecha', 'Fecha'); ?>

		<?php echo Form::date('fecha', \Carbon\Carbon::now(), ['class' => 'form-control', 'required']); ?>

	</div>
	<?php echo Form::label(null, 'Tiempo predicado (horas:minutos)'); ?>

	<div class="form-group input-group">

		<?php echo Form::number('horas', null, ['class' => 'form-control', 'placeholder' => 'Horas', 'required']); ?>

		<span class="input-group-addon">:</span>
		<?php echo Form::number('minutos', null, ['class' => 'form-control', 'placeholder' => 'Minutos (opcional)']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('acompanante', 'Acompañante'); ?>

		<?php echo Form::text('acompanante', null, ['class' => 'form-control', 'placeholder' => 'Nombre (opcional)']); ?>

	</div>
	<?php echo Form::label('publicaciones', 'Publicaciones y Videos'); ?>

	<div class="form-group input-group">		
		<?php echo Form::number('publicaciones', null, ['class' => 'form-control', 'placeholder' => 'Impresas y digitales (opcional)']); ?>

	<span class="input-group-addon"></span>
		<?php echo Form::number('videos', null, ['class' => 'form-control', 'placeholder' => 'Cantidad de reproducciones (opcional)']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

	</div>
	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>