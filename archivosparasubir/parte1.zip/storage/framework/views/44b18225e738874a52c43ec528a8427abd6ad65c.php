<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fa-svg-with-js.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top" id="navbar">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <?php if(auth()->guard()->guest()): ?>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <i class="fab fa-laravel"></i> <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                    <?php else: ?>
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i></a>
                    <?php endif; ?>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <?php if(auth()->guard()->guest()): ?>
                            <li></li>
                        <?php else: ?>
                            <?php if(Auth::user() && Auth::user()->admin()): ?>
                                <li><a href="<?php echo route('users.index'); ?>"><i class="fas fa-users"></i> Usuarios</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('actividad.create')); ?>"><i class="fas fa-book"></i> Actividad</a></li>
                            <li><a href="<?php echo e(route('revisita.create')); ?>"><i class="fas fa-address-book"></i> Revisitas</a></li>
                            <li><a href="<?php echo e(route('informe')); ?>"><i class="fas fa-newspaper"></i> Informe</a></li>
                            <li><a href="<?php echo e(route('ayuda.main')); ?>"><i class="fas fa-question-circle"></i> Ayuda</a></li>
                        <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true"><i class="fas fa-user-circle"></i> 
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i> 
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('ayuda.version')); ?>"><i class="fas fa-info-circle"></i> v0.2</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
    <div class="row">
        <div class="col-md-12">
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fontawesome-all.min.js')); ?>"></script>
    <script>
        function preguntar(id){
       eliminar=confirm("¿Deseas eliminar este registro?");
       if (eliminar)
       window.location.href="actividad/"+id+"/destroy";//página web a la que te redirecciona si confirmas la eliminación
        else
        alert('No se ha podido eliminar el registro..')
        }
    </script>
</body>
</html>
