<?php $__env->startSection('title', 'Mi Actividad'); ?>

<?php $__env->startSection('content'); ?>

	<a href="<?php echo e(route('actividad.create')); ?>" class="btn btn-primary">Cargar Actividad</a>
	<br>
	<hr>
	<div class="table-responsive">
		<table class="table">
		  <thead>
		    <tr>
		      <th>Fecha</th>
		      <th>Horas</th>
		      <th>Acompañante</th>
		      <th>Publicaciones</th>
		      <th>Videos</th>
		      <th>Opciones</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
		      <td><?php echo Carbon\Carbon::parse($a->fecha)->toFormattedDateString(); ?></td>
		      <?php if($a->minutos > 9): ?>
		      <td><?php echo e($a->horas); ?>:<?php echo e($a->minutos); ?></td>
		      <?php else: ?>
		      <td><?php echo e($a->horas); ?>:0<?php echo e($a->minutos); ?></td>
		      <?php endif; ?>
		      <td><?php echo e($a->acompanante); ?></td>
		      <td><?php echo e($a->publicaciones); ?></td>
		      <td><?php echo e($a->videos); ?></td>
		      <td><a href="javascript:preguntar(<?php echo e($a->id); ?>)" class="btn btn-danger btn-sm">Borrar</a></td>
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </tbody>
		</table>
	</div>
		<div class="text-center">
		<?php echo $actividades->render(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>