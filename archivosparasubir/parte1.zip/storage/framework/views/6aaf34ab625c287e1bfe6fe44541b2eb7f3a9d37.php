<?php $__env->startSection('title', 'Error 401: Acceso Denegado'); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center">
<p align="middle">
	<img src="<?php echo e(asset('images/401.jpeg')); ?>" class="img-responsive" width="50%" height="50%"></p>
<h2>Ups! No tienes acceso a este panel de Administración</h2>
<a href="<?php echo route('home'); ?>">Volver al inicio</a>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>