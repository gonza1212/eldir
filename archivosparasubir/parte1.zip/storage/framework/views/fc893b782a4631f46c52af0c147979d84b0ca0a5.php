<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading">
        <h3>¡Bienvenido <?php echo e(Auth::user()->name); ?>! <i class="fas fa-hand-spock"></i></h3>
    </div>
    <div class="panel-body text-center">
        <p>Como vas este mes:</p>
        <h3><?php echo e($actividadActual[0]); ?><small> horas con </small><?php echo e($actividadActual[1]); ?><small> minutos, </small><?php echo e($actividadActual[2]); ?><small> publicaciones y </small><?php echo e($actividadActual[3]); ?><small> videos.</small></h3>
        <hr>
        <p>Has salido: </p>
        <?php if($veces == 1): ?>
        <h3><?php echo e($veces); ?><small> vez</small></h3>
        <?php else: ?>
        <h3><?php echo e($veces); ?><small> veces</small></h3>
        <?php endif; ?>
        <br>
        <a href="<?php echo e(route('actividad.index')); ?>" class="btn btn-primary">Ver registros</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>